var fila = []
let proximoID = 1

let mira = -1

function cadastrar(){
    var subway = {
        id: "",
        pao: "",
        tamanho: "",
        recheio: "",
        adicionais: [],
        saladas: [],
        molhos: []
    }
    subway.id = proximoID
    proximoID++
    subway.pao = document.getElementById("pao").value
    subway.tamanho = document.getElementById("tamanho").value
    subway.recheio = document.getElementById("recheio").value

    if(document.getElementById('bacon').checked) subway.adicionais.push(' Bacon')
    if(document.getElementById('presunto').checked) subway.adicionais.push(' Presunto')
    if(document.getElementById('creamCheese').checked) subway.adicionais.push(' Cream Cheese')

    if(document.getElementById('alface').checked) subway.saladas.push(' Alface')
    if(document.getElementById('tomate').checked) subway.saladas.push(' Tomate')
    if(document.getElementById('pepino').checked) subway.saladas.push(' Pepino')
    if(document.getElementById('cebola').checked) subway.saladas.push(' Cebola')
    if(document.getElementById('pimentão').checked) subway.saladas.push(' Pimentão')
    if(document.getElementById('azeitona').checked) subway.saladas.push(' Azeitona')

    if(document.getElementById('barbecue').checked) subway.molhos.push(' Barbecue')
    if(document.getElementById('maioneseTemp').checked) subway.molhos.push(' Maionese temperada')
    if(document.getElementById('molhoAgri').checked) subway.molhos.push(' Molho agridoce')
    if(document.getElementById('chipotle').checked) subway.molhos.push(' Chipotle')

    // subway.adicionais = document.getElementById("adicionais").value
    // subway.saladas = document.getElementById("saladas").value
    // subway.molhos = document.getElementById("molhos").value

    fila.push(subway)

    limparInputs()
    mostrar()
    
}

function mostrar(){

    document.getElementById("divSanduiches").innerHTML = ''

    for(var i=0; i<fila.length; i++){

        document.getElementById("divSanduiches").innerHTML += "Sanduíche: " + fila[i].id +
        "</br> Pão: " + fila[i].pao + 
        "</br> Tamanho: " + fila[i].tamanho +
        "</br> Recheio: " + fila[i].recheio +
        "</br> Adicionais: " + fila[i].adicionais +
        "</br> Saladas: " + fila[i].saladas +
        "</br> Molhos: " + fila[i].molhos + "<hr>"
        
    }

}

function limparInputs(){
    document.getElementById("pao").value = ''
    document.getElementById("tamanho").value = ''
    document.getElementById("recheio").value = ''

    document.getElementById("bacon").checked = false
    document.getElementById("presunto").checked = false
    document.getElementById("creamCheese").checked = false

    document.getElementById("alface").checked = false
    document.getElementById("tomate").checked = false
    document.getElementById("pepino").checked = false
    document.getElementById("cebola").checked = false
    document.getElementById("pimentão").checked = false
    document.getElementById("azeitona").checked = false

    document.getElementById("barbecue").checked = false
    document.getElementById("maioneseTemp").checked = false
    document.getElementById("molhoAgri").checked = false
    document.getElementById("chipotle").checked = false
   
    document.getElementById("pao").focus()

}
function pesquisar(){

    document.getElementById('pesquisar').style.display = 'block'

    // const select = document.querySelector('#sanduiches');
    select.innerHTML = ''
    select.options = []
    select.options[select.options.length] = new Option ("--", "--")

    for(let i=0; i<fila.length; i++){
        select.options[select.options.length] = new Option(fila[i].id, fila[i].id);
    }
}

const select = document.querySelector('#sanduiches');

select.addEventListener('change', mostraRegistro)

function mostraRegistro(){
    console.log('Selecionado')
    // alert(select.value)

    for(let i=0; i<fila.length; i++){
        if(fila[i].id == select.value){
            mira = i
            console.log(i)
            document.getElementById("divSanduiches").innerHTML = "Sanduíche: " + fila[i].id +
            "</br> Pão: " + fila[i].pao + 
            "</br> Tamanho: " + fila[i].tamanho +
            "</br> Recheio: " + fila[i].recheio +
            "</br> Adicionais: " + fila[i].adicionais +
            "</br> Saladas: " + fila[i].saladas +
            "</br> Molhos: " + fila[i].molhos + "<hr>"
        }
    }
}

function editar(){
    document.getElementById("pao").value = fila[mira].pao
    document.getElementById("tamanho").value = fila[mira].tamanho
    document.getElementById("recheio").value = fila[mira].recheio

    for(let i=0; i<fila[mira].adicionais.length; i++){
        if(fila[mira].adicionais[i] == " Bacon") document.getElementById("bacon").checked = true
        if(fila[mira].adicionais[i] == " Presunto") document.getElementById("presunto").checked = true
        if(fila[mira].adicionais[i] == " Cream Cheese") document.getElementById("creamCheese").checked = true
        
        
    }
    
    for(let i=0; i<fila[mira].saladas.length; i++){
        if(fila[mira].saladas[i] == " Alface") document.getElementById("alface").checked = true
        if(fila[mira].saladas[i] == " Tomate") document.getElementById("tomate").checked = true
        if(fila[mira].saladas[i] == " Pepino") document.getElementById("pepino").checked = true
        if(fila[mira].saladas[i] == " Cebola") document.getElementById("cebola").checked = true
        if(fila[mira].saladas[i] == " Pimentão") document.getElementById("pimentão").checked = true
        if(fila[mira].saladas[i] == " Azeitona") document.getElementById("azeitona").checked = true   
    }
    
    for(let i=0; i<fila[mira].molhos.length; i++){
        if(fila[mira].molhos[i] == " Barbecue") document.getElementById("barbecue").checked = true
        if(fila[mira].molhos[i] == " Maionese temperada") document.getElementById("maioneseTemp").checked = true
        if(fila[mira].molhos[i] == " Molho agridoce") document.getElementById("molhoAgri").checked = true
        if(fila[mira].molhos[i] == " Chipotle") document.getElementById("chipotle").checked = true
    }

    document.getElementById("pao").value
    document.getElementById("tamanho").value
    document.getElementById("recheio").value

    if(document.getElementById('bacon').checked) subway.adicionais.push(' Bacon')
    if(document.getElementById('presunto').checked) subway.adicionais.push(' Presunto')
    if(document.getElementById('creamCheese').checked) subway.adicionais.push(' Cream Cheese')

    if(document.getElementById('alface').checked) subway.saladas.push(' Alface')
    if(document.getElementById('tomate').checked) subway.saladas.push(' Tomate')
    if(document.getElementById('pepino').checked) subway.saladas.push(' Pepino')
    if(document.getElementById('cebola').checked) subway.saladas.push(' Cebola')
    if(document.getElementById('pimentão').checked) subway.saladas.push(' Pimentão')
    if(document.getElementById('azeitona').checked) subway.saladas.push(' Azeitona')

    if(document.getElementById('barbecue').checked) subway.molhos.push(' Barbecue')
    if(document.getElementById('maioneseTemp').checked) subway.molhos.push(' Maionese temperada')
    if(document.getElementById('molhoAgri').checked) subway.molhos.push(' Molho agridoce')
    if(document.getElementById('chipotle').checked) subway.molhos.push(' Chipotle')
}

function salvar(){
    limparInputs()
    mostrar()
}

function deletar(){ 
    if(confirm("Quer mesmo deletar?")){
        fila.splice(mira, 1)   
    }

    mira = -1
    document.getElementById("divSanduiches").innerHTML = ''
    pesquisar()
}



// function teste(){
//     alert('oi')
// }